package dao_impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.SalaDAO;
import entit�.Sala;

public class SalaDAOPostgresImpl implements SalaDAO {
	
	private Connection connection;

	private PreparedStatement insertSalaPS;
	private PreparedStatement deleteSalaPS;
	private PreparedStatement updateSalaPS;
	
	private PreparedStatement getSalaByAttributiPS;
	
	public SalaDAOPostgresImpl(Connection c) throws SQLException {
		
		connection = c;
		
		insertSalaPS = connection.prepareStatement("CALL Insert_Sala(?, ?, ?, ?, ?);");
		deleteSalaPS = connection.prepareStatement("DELETE FROM SALA WHERE CodSala = ?;");
		updateSalaPS = connection.prepareStatement("UPDATE SALA SET Citt� = ?, Provincia = ?, Indirizzo = ?, NumeroCivico = ?, NumPosti = ? WHERE CodSala = ?;");
		
		getSalaByAttributiPS = connection.prepareStatement("SELECT * "
															+ "FROM SALA "
															+ "WHERE Citt� ILIKE ? AND "
																	+ "Provincia ILIKE ? AND "
																	+ "Indirizzo ILIKE ? AND "
																	+ "(? = -1 OR NumeroCivico = ?) AND "
																	+ "NumPosti BETWEEN ? AND ? "
															+ "ORDER BY CodSala;");
	}
	
	public void insertSala(Sala s) throws SQLException {
		
		insertSalaPS.setString(1, s.getCitt�());
		insertSalaPS.setString(2, s.getProvincia());
		insertSalaPS.setString(3, s.getIndirizzo());
		insertSalaPS.setInt(4, s.getNumeroCivico());
		insertSalaPS.setInt(5, s.getNumeroPosti());
		
		insertSalaPS.execute();
	}
	public void deleteSala(Sala s) throws SQLException {
		
		deleteSalaPS.setInt(1, s.getCodice());
		
		deleteSalaPS.execute();
	}
	public void updateSala(Sala s) throws SQLException {
		
		updateSalaPS.setString(1, s.getCitt�());
		updateSalaPS.setString(2, s.getProvincia());
		updateSalaPS.setString(3, s.getIndirizzo());
		updateSalaPS.setInt(4, s.getNumeroCivico());
		updateSalaPS.setInt(5, s.getNumeroPosti());
		updateSalaPS.setInt(6, s.getCodice());
		
		updateSalaPS.execute();
	}
	
	public ArrayList<Sala> getSalaByAttributi(String citt�, String provincia, String indirizzo, String numCivico, String minPosti, String maxPosti) throws SQLException {
		
		int numCiv, minimo, massimo;
		
		if(numCivico.isBlank())
			numCiv = -1;
		else
			numCiv = Integer.parseInt(numCivico);
		
		if(minPosti.isBlank())
			minimo = Integer.MIN_VALUE;
		else
			minimo = Integer.parseInt(minPosti);
		
		if(maxPosti.isBlank())
			massimo = Integer.MAX_VALUE;
		else
			massimo = Integer.parseInt(maxPosti);
		
		getSalaByAttributiPS.setString(1, "%" + citt� + "%");
		getSalaByAttributiPS.setString(2, "%" + provincia + "%");
		getSalaByAttributiPS.setString(3, "%" + indirizzo + "%");
		getSalaByAttributiPS.setInt(4, numCiv);
		getSalaByAttributiPS.setInt(5, numCiv);
		getSalaByAttributiPS.setInt(6, minimo);
		getSalaByAttributiPS.setInt(7, massimo);
		
		ResultSet rs = getSalaByAttributiPS.executeQuery();
		
		ArrayList<Sala> lista = new ArrayList<Sala>();
		
		while(rs.next()) {
			
			String citta = rs.getString("Citt�");
			String prov = (rs.getString("Provincia"));
			String ind = (rs.getString("Indirizzo"));
			int civico = rs.getInt("NumeroCivico");
			int numPosti = rs.getInt("NumPosti");
			int codice = rs.getInt("CodSala");
			
			Sala s = new Sala(codice, citta, prov, ind, civico, numPosti);
			
			lista.add(s);
		}
		
		return lista;
	}
}
